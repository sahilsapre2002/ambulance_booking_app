package com.example.eab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register_User extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        EditText cuseremail,cuserphne,cname,cage,cusername,cpassword,cretype;
        Button btn1,btn2;
        userDBHelper DB;

        cusername = (EditText) findViewById(R.id.username);
        cpassword = (EditText) findViewById(R.id.password);
        cretype = (EditText) findViewById(R.id.retype);
        cuseremail= (EditText) findViewById(R.id.useremail);
        cuserphne= (EditText) findViewById(R.id.userphne);
        cname= (EditText) findViewById(R.id.name);
        cage= (EditText) findViewById(R.id.age);

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);


        DB = new userDBHelper(this);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = cusername.getText().toString();
                String pass = cpassword.getText().toString();
                String repass = cretype.getText().toString();
                String email = cuseremail.getText().toString();
                String phne = cuserphne.getText().toString();
                String name = cname.getText().toString();
                String age = cage.getText().toString();

                if(user.equals("")||pass.equals("")||repass.equals("")||email.equals("")||phne.equals("")||name.equals("")||age.equals(""))
                    Toast.makeText(Register_User.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser==false){
                            Boolean insert = DB.insertdata(user, pass,name,email,phne, Integer.valueOf(age));
                            if(insert==true){
                                Toast.makeText(Register_User.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), User_Login.class);
                                startActivity(intent);
                            }else{
                                Toast.makeText(Register_User.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(Register_User.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Register_User.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                    }
                } }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), User_Login.class);
                startActivity(intent);
            }
        });

            }

    }
