package com.example.eab;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        Button see_drivers,nearby_hospital,emergency_call;
        DriverDbhelper db;
        db=new DriverDbhelper(this);
        
        see_drivers=findViewById(R.id.seeamb);
        nearby_hospital=findViewById(R.id.naerbyhospital);
        emergency_call=findViewById(R.id.Emergency);
        
        see_drivers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(homepage.this, "drivers", Toast.LENGTH_SHORT).show();
                Cursor t = db.getinfo();
                if (t.getCount()==0){
                    Toast.makeText(homepage.this,"No data found", Toast.LENGTH_SHORT).show();
                }StringBuffer buffer=new StringBuffer();
                while (t.moveToNext())
                {
                    buffer.append("Ambulance Number::"+t.getString(0)+"\n");
                    buffer.append("Type of Ambulance::"+t.getString(1)+"\n");
                    buffer.append("Description of Vehicle::"+t.getString(2)+"\n");
                    buffer.append("Driver Name::"+t.getString(3)+"\n");
                    buffer.append("Driver Phone Number::"+t.getString(4)+"\n\n");

                }
                AlertDialog.Builder builder=new AlertDialog.Builder(homepage.this);
                builder.setCancelable(true);
                builder.setTitle("Drivers Informations");
                builder.setMessage(buffer.toString());
                builder.show();
            }


        });


        nearby_hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent hyperlinkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/nearby+hospital+in+kambalpada/@19.2113435,73.0954827,15z/data=!3m1!4b1"));
                startActivity(hyperlinkIntent);
            }
        });
        emergency_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Number="108";
                Intent intent=new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:"+Number));
//        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
//            return;
//        }
                startActivity(intent);
            }
        });
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Click on Logout button", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                Toast.makeText(this, "LOGOUT", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(), Admin_Client.class);
                startActivity(intent);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
//    public void Btn_ambulance_onClick(View view){
//        String Number="108";
//        Intent intent=new Intent(Intent.ACTION_CALL);
//        intent.setData(Uri.parse("tel:"+Number));
////        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
////            return;
////        }
//        startActivity(intent);
//
//    }

}