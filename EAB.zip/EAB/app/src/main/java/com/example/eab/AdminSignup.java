package com.example.eab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminSignup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_signup);

        EditText Emailid,Phonenumber,adminname,Admin_username,admin_password,admin_retype;
        Button adminR_btn1,adminR_btn2;
        AdminDBHelper DB;
        DB=new AdminDBHelper(this);
        Emailid=findViewById(R.id.Email_id);
        Phonenumber=findViewById(R.id.Phone_number);
        adminname=findViewById(R.id.admin_name);
        Admin_username=findViewById(R.id.AdminR_username);
        admin_password=findViewById(R.id.adminR_password);
        admin_retype=findViewById(R.id.adminR_retype);
        adminR_btn1=findViewById(R.id.adminR_btn1);
        adminR_btn2=findViewById(R.id.adminR_btn2);

adminR_btn1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        String user = Admin_username.getText().toString();
        String pass = admin_password.getText().toString();
        String repass = admin_retype.getText().toString();
        String name = adminname.getText().toString();
        String email = Emailid.getText().toString();
        String phone = Phonenumber.getText().toString();

        if(user.equals("")||pass.equals("")||repass.equals("")||name.equals("")||email.equals("")||phone.equals("")){
            Toast.makeText(AdminSignup.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
        }
        if(pass.equals(repass)){
            Boolean checkuser = DB.checkusername(user);
            if(checkuser==false){
                Boolean insert = DB.insertdata(user, pass, name, email, phone);
                if(insert==true){
                    Toast.makeText(AdminSignup.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), admin_Login.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(AdminSignup.this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                Toast.makeText(AdminSignup.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(AdminSignup.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
        }
    }
    });

adminR_btn2.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(getApplicationContext(),admin_Login.class);
        startActivity(intent);
    }
});


    }
}