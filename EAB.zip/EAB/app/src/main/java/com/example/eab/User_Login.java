package com.example.eab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class User_Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText cusername,password;
        Button Login,Signup;
        userDBHelper DB;

        cusername=findViewById(R.id.username1);
        password=findViewById(R.id.password1);
        Login=findViewById(R.id.btn21);
        Signup=findViewById(R.id.btn22);
        DB = new userDBHelper(this);
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), Register_User.class);
                startActivity(intent);
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user =cusername.getText().toString();
                String pass =password.getText().toString();
                if(user.equals("")||pass.equals(""))
                    Toast.makeText(User_Login.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if(checkuserpass==true){
                        Toast.makeText(User_Login.this, "Sign in successfull", Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(getApplicationContext(), homepage.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(User_Login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }
}