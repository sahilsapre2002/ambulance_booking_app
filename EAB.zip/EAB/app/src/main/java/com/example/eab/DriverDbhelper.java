package com.example.eab;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DriverDbhelper extends SQLiteOpenHelper {
    public static final String DBNAME="driver.db";

    public DriverDbhelper(Context context) {
        super(context,"driver.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table drivers (AmbulanceNum TEXT primary key,Type  TEXT,Description TEXT,DriverName TEXT,Phone_number TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop Table if exists drivers");
    }

    public boolean insert_data(String AmbulanceNum, String Type, String Description, String DriverName, String Phone_number){
        SQLiteDatabase db=this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("AmbulanceNum",AmbulanceNum);
        contentValues.put("Type",Type);
        contentValues.put("Description",Description);
        contentValues.put("DriverName",DriverName);
        contentValues.put("Phone_number",Phone_number);

        long result = db.insert("drivers",null,contentValues);
        if (result==1)return false;
        else
            return true ;
    }
    public boolean checkdl(String AmbulanceNum) {                     // checking user name
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from drivers where AmbulanceNum=?", new String[]{AmbulanceNum});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public Cursor getinfo() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from drivers", null);
        return cursor;
    }
}
