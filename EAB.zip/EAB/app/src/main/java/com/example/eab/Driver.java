package com.example.eab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Driver extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver);

        Button Register;
        EditText Driver_name,Driver_phone,Ambulance_No,Type_of,description;
        DriverDbhelper DB;
        DB=new DriverDbhelper(this);

        Driver_name=findViewById(R.id.Dname);
        Driver_phone=findViewById(R.id.Dphone);
        Ambulance_No=findViewById(R.id.Number);
        Type_of=findViewById(R.id.type);
        description=findViewById(R.id.descp);
        Register=findViewById(R.id.signup);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String name=Driver_name.getText().toString();
            String phne= Driver_phone.getText().toString();
            String Vnum=Ambulance_No.getText().toString();
            String type=Type_of.getText().toString();
            String desc=description.getText().toString();

            if(name.equals("")||phne.equals("")||Vnum.equals("")||type.equals("")||desc.equals("")) {
                Toast.makeText(Driver.this, "Enter all the fields", Toast.LENGTH_SHORT).show();
            }else {
                Boolean checkuser = DB.checkdl(Vnum);
                if (checkuser == false) {
                    Boolean insert = DB.insert_data(Vnum, type, desc, name, phne);
                    if (insert == true) {
                        Toast.makeText(Driver.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), admin_home.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(Driver.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }


            }
            }
        });
    }
}