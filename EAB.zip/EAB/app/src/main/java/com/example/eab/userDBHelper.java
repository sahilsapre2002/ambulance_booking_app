package com.example.eab;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class userDBHelper extends SQLiteOpenHelper {
    public static final String DBname="userauth.db";  //name set of database
    public userDBHelper(Context context) {
        super(context, "userauth.db", null, 1);
    } //const of sqlite

    @Override
    public void onCreate(SQLiteDatabase db) {       //oncreate method for create an db name as db
        db.execSQL("create Table users(username TEXT primary key, password TEXT,name TEXT,useremail TEXT,age INTEGER,userphne TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {  //onupgrade method is use for any update in db
        db.execSQL("drop  table if exists users");
    }
    public boolean insertdata(String username, String password, String name, String useremail,String userphne,Integer age) {   // Inserting username and password to SQLITE TABLE
        SQLiteDatabase MYDB=this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("name",name);
        contentValues.put("useremail",useremail);
        contentValues.put("userphne",userphne);
        contentValues.put("age",age);

        long result = MYDB.insert("Users",null,contentValues);
        if (result==1)return false;
        else
            return true ;
    }
    public boolean checkusername(String username) {                     // checking user name
        SQLiteDatabase MYDB = this.getReadableDatabase();
        Cursor cursor = MYDB.rawQuery("Select * from users where username=?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public boolean checkusernamepassword(String username,String password) {     //checking passwd
        SQLiteDatabase MYDB = this.getReadableDatabase();
        Cursor cursor = MYDB.rawQuery("Select * from users where username=? and password=?", new String[]{username,password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

}
