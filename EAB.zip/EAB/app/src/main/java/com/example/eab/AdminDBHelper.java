package com.example.eab;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AdminDBHelper extends SQLiteOpenHelper {

    public static final String DBNAME="admin.db";

    public AdminDBHelper(Context context) {
        super(context,"admin.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase ADMINDB) {
        ADMINDB.execSQL("create Table admins (username TEXT primary key, password  TEXT,Name TEXT,Email_id TEXT,Phone_number TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase ADMINDB, int i, int i1) {
        ADMINDB.execSQL("drop Table if exists admins");
    }
    public boolean insertdata(String username, String password, String Name, String Email_id, String Phone_number){
        SQLiteDatabase ADMINDB=this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("Name",Name);
        contentValues.put("Email_id",Email_id);
        contentValues.put("Phone_number",Phone_number);

        long result = ADMINDB.insert("admins",null,contentValues);
        if (result==1)return false;
        else
            return true ;
    } public boolean checkusername(String username) {                     // checking user name
        SQLiteDatabase ADMINDB = this.getReadableDatabase();
        Cursor cursor = ADMINDB.rawQuery("Select * from admins where username=?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public boolean checkusernamepassword(String username,String password) {     //checking passwd
        SQLiteDatabase ADMINDB = this.getReadableDatabase();
        Cursor cursor = ADMINDB.rawQuery("Select * from admins where username=? and password=?", new String[]{username, password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
}
